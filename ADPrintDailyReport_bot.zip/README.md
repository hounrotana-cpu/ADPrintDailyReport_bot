# ADPrint Daily Report Bot

Summarizes original PayWay Telegram text notifications. USD and KHR totals stay separate. Transaction IDs deduplicate globally. Money uses integer hundredths, never floats. SQLite stores payments, setup, polling offset and report progress.

## Render deployment (not deployed yet)

Create a **Background Worker** from this repository, Python runtime:
- Build command: `pip install -r requirements.txt`
- Start command: `python main.py`
- One instance only.
- Attach a **persistent disk** at `/var/data`, 1 GB.
- Set `DB_PATH=/var/data/payway.sqlite3`.
- Set secret `BOT_TOKEN` to the token from BotFather.
- Set secret `SETUP_CODE` to a new random string of at least 12 characters.

Workers and persistent disks are paid Render resources. Review the price in the Dashboard before deploying. No resources are created by these files. Do not use ephemeral storage for real payment records.

## One-time setup

Enable Bot-to-Bot Communication for the report bot. Add it to the Payway APV group with Group Privacy disabled (or appropriate admin status). Deploy the worker. In the group, **reply to an original text payment notification from the actual PayWay bot**, and send `/setup YOUR_SETUP_CODE`. The sender must be a group admin. Verify the replied-to sender is the real PayWay bot before setup. The first successful setup locks the source bot and group IDs; subsequent setup commands cannot rebind them. Delete your setup command afterward. The replied-to historical payment is NOT imported.

After setup, wait for a new genuine PayWay payment and run `/today`; compare the amount and transaction with ABA. Never assume deployment alone proves message reception.

## Reports

All group members may use `/today`, `/yesterday`, `/month`, `/status`. Replies stay in the configured group. At **00:05 Cambodia time**, sends the previous calendar day's total, with catch-up after restart. The first day is partial from setup time. Payment dates come from the notification; the missing year is resolved near the Telegram message date. Reports are based on received notifications, not an authoritative bank statement or profit calculation.

Unknown source messages and conflicting transaction IDs are flagged in report counts and excluded from new totals (original stored amounts remain). Inspect those messages in Telegram. Refunds/reversals are not automatically deducted. Source message edits with conflicting data require manual reconciliation; Telegram deletions do not remove ledger entries. Supported amount prefixes: $, USD, KHR, ៛. Other formats are flagged for review. No payer names or full payment messages are persisted.

Bot API cannot import arbitrary old group history. Updates expire at Telegram after 24 hours; downtime beyond this can cause missing transactions. Daily reports already sent do not automatically resend for later corrections; `/yesterday` recalculates. A crash between sending a report and checkpointing may duplicate the report, but not payment totals. Keep database backups and reconcile against ABA.

## Local validation

`python -m unittest -v`

No tokens are committed. Never paste tokens into GitHub files, screenshots, or public messages.
